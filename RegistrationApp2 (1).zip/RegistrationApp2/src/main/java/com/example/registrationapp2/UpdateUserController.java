package com.example.registrationapp2;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class UpdateUserController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextField newLoginField;

    @FXML
    private TextField newPasswordField;

    @FXML
    private Button updateLogin;

    @FXML
    void initialize() {
        assert newLoginField != null : "fx:id=\"newLoginField\" was not injected: check your FXML file 'updateUser.fxml'.";
        assert newPasswordField != null : "fx:id=\"newPasswordField\" was not injected: check your FXML file 'updateUser.fxml'.";
        assert updateLogin != null : "fx:id=\"updateLogin\" was not injected: check your FXML file 'updateUser.fxml'.";

    }

}
