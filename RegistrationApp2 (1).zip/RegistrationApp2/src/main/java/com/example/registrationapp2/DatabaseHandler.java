package com.example.registrationapp2;

import java.sql.*;
import java.util.List;

public class DatabaseHandler extends Configs implements IDB{
    @Override
    public Connection getConnection() throws SQLException, ClassNotFoundException {
        String connectionUrl = "jdbc:postgresql://" + dbHost + ":" + dbPort + "/" + dbName;
        try {
            Class.forName("org.postgresql.Driver");

            Connection con = DriverManager.getConnection(connectionUrl, dbUser, dbPass);

            return con;
        } catch (Exception e) {
            System.out.println(e);
            return null;
        }
    }

    public void signUp(User user)  {
     String sql = "INSERT INTO users(username, email, iin, password) VALUES (?,?,?,?)";


       try {
           PreparedStatement preparedStatement = getConnection().prepareStatement(sql);

           preparedStatement.setString(1, user.getUsername());
           preparedStatement.setString(2, user.getEmail());
           preparedStatement.setString(3, user.getIin());
           preparedStatement.setString(4, user.getPassword());
            preparedStatement.execute();
       }catch (SQLException e){
           e.printStackTrace();
       }
       catch (ClassNotFoundException e){
           e.printStackTrace();
       }

    }


    public ResultSet getUser(User user){
        ResultSet resultSet = null;
        try {
            String sql = "SELECT * FROM users WHERE username=? AND password=?";
            PreparedStatement preparedStatement =
                    getConnection().prepareStatement(sql);

            preparedStatement.setString(1, user.getUsername());
            preparedStatement.setString(2, user.getPassword());
            resultSet = preparedStatement.executeQuery();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
        return resultSet;
    }

    public void updateUser(User user){
        try {
            String sql = "UPDATE users SET password=?";
            PreparedStatement preparedStatement = getConnection().prepareStatement(sql);
            preparedStatement.setString(1, user.getPassword());
            preparedStatement.executeQuery();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }
}
