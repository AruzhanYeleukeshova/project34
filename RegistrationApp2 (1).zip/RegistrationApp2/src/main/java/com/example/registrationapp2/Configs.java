package com.example.registrationapp2;

public class Configs {
    protected String dbHost = "localhost";
    protected String dbPort = "5432";
    protected String dbUser = "postgres";
    protected String dbPass = "0000";
    protected String dbName = "Registration";
}
