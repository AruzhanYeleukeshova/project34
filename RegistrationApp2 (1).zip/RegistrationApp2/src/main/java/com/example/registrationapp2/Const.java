package com.example.registrationapp2;

public class Const {
    public static final String USER_TABLE = "users";
    public static final String USER_ID = "id";
    public static final String USER_USERNAME = "username";
    public static final String USER_EMAIL = "email";
    public static final String USER_IIN = "iin";
    public static final String USER_PASSWORD = "password";

}
